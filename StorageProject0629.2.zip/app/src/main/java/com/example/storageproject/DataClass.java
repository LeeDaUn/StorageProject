package com.example.storageproject;

public class DataClass {
    private int profilePhoto;
    private String name;
    private String content;

    public DataClass(int profilePhoto,String name,String content){
        this.profilePhoto = profilePhoto;
        this.name = name;
        this.content = content;
    }

    public int getProfilePhoto(){
        return this.profilePhoto;
    }
    public String getName(){
        return this.name;
    }
    public String getContent(){
        return this.content;
    }
}
