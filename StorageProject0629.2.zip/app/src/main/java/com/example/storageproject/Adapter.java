package com.example.storageproject;

public class Adapter {

}
