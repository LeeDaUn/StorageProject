package com.example.storageproject;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

import com.google.android.material.navigation.NavigationView;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener{
    ImageView iv_Menu;
    ImageButton img_Vegetable,img_Fruit,img_Marine,img_Meat,img_Seasoning;
    NavigationView navigationView;
    DrawerLayout drawerLayout;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        iv_Menu = findViewById(R.id.iv_menu);
        img_Vegetable = findViewById(R.id.img_vegetable);
        img_Fruit = findViewById(R.id.img_fruit);
        img_Marine = findViewById(R.id.img_marine);
        img_Meat = findViewById(R.id.img_meat);
        img_Seasoning = findViewById(R.id.img_seasoning);
        navigationView = findViewById(R.id.navigation);
        navigationView.setNavigationItemSelectedListener(this);
        drawerLayout = findViewById(R.id.drawer);

        img_Vegetable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentVegetable = new Intent(MainActivity.this,VegetableActivity.class);
                startActivity(intentVegetable);
            }
        });

        iv_Menu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                drawerLayout.openDrawer(GravityCompat.START);
            }
        });
    }
    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        switch(item.getItemId()){
            case R.id.action_menu1:
                Intent intentMenu1 = new Intent(MainActivity.this,IntnetMenu1.class);
                startActivity(intentMenu1);
                break;
//            case R.id.action_menu2:
//                Intent intentMenu2 = new Intent(MainActivity.this,IntentMenu2.class);
//                startActivity(intentMenu2);
//                break;
        }
        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }
}