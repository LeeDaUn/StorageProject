package com.example.storageproject;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

public class IntnetMenu1 extends AppCompatActivity {
    TextView tv_NewData;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intnet_menu1);
        tv_NewData = findViewById(R.id.tv_newData);
    }
}