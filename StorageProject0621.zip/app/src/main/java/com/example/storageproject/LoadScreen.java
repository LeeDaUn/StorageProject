package com.example.storageproject;

import androidx.appcompat.app.AppCompatActivity;
import android.animation.ObjectAnimator;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;
import android.widget.TextView;

public class LoadScreen extends AppCompatActivity {

    ImageView imgload;
    TextView tvloadtitle;
    private static final int _Width = 300;
    private static final int _Height = 400;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_load_screen);

        imgload = (ImageView) findViewById(R.id.img_Title);
        tvloadtitle = (TextView) findViewById(R.id.tv_loadTitle);

        //애니메이션
        ObjectAnimator animator = ObjectAnimator.ofFloat(imgload, "translationY", imgload.getY()-200);
        Animation anim = AnimationUtils.loadAnimation(getApplicationContext(),R.anim.alpha_anim);
        Animation anim2 = AnimationUtils.loadAnimation(this,R.anim.alpha_anim2);
        animator.setDuration(1000);
        animator.start();

        Handler mHandler = new Handler();
        mHandler.postDelayed(new Runnable() { public void run() {
            tvloadtitle.startAnimation(anim);
            tvloadtitle.setVisibility(View.VISIBLE);
                Handler mHandler = new Handler();
                mHandler.postDelayed(new Runnable() { public void run() {
                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(intent);
                    finish(); }
                }, 1500); }
            }, 800);
    }
}