package com.example.storageproject;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;

import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class VegetableActivity extends AppCompatActivity {

    ListView listView = null;
    ArrayList<ListViewItem> vegetableList;
    ImageView img_Revert;
    TextView tv_TitleName;
    EditText edt_TextFilter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vegetable);

        img_Revert = findViewById(R.id.iv_revert);
        tv_TitleName = findViewById(R.id.tv_titleName);
        edt_TextFilter = findViewById(R.id.edt_textFilter);

        vegetableList = new ArrayList<ListViewItem>();

        ListView listView = (ListView)findViewById(R.id.listView_vegetable);
        final ListViewAdapter myAdapter = new ListViewAdapter(this,vegetableList);

        listView.setAdapter(myAdapter);

        myAdapter.addItem(ContextCompat.getDrawable(this,R.drawable.vegetable_sangchoo),"상추","서늘한 기후를 좋아함(15℃~25℃ 최적조건임)");
        myAdapter.addItem(ContextCompat.getDrawable(this,R.drawable.vegetable_gamja),"감자","테스트용");
        myAdapter.addItem(ContextCompat.getDrawable(this,R.drawable.vegetable_sesam_eleaf),"깻잎","테스트용");
        myAdapter.addItem(ContextCompat.getDrawable(this,R.drawable.vegetable_goguma),"고구마","테스트용");
        myAdapter.addItem(ContextCompat.getDrawable(this,R.drawable.vegetable_garlic),"마늘","테스트용");
        myAdapter.addItem(ContextCompat.getDrawable(this,R.drawable.loadimage),"브로콜리","테스트용");
        myAdapter.addItem(ContextCompat.getDrawable(this,R.drawable.vegetable_cabbage),"양배추","테스트용");
        myAdapter.addItem(ContextCompat.getDrawable(this,R.drawable.vegetable_lettuce),"양상추","테스트용");

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView parent, View view, int position, long id) {
                Intent intentVegetableSub = new Intent(VegetableActivity.this,VegetableSubActivity.class);
                intentVegetableSub.putExtra("Name",myAdapter.getItem(position).getTitle());
//                intentVegetableSub.putExtra("Name",myAdapter.getView(name).get(position).getTitle());
                startActivity(intentVegetableSub,ActivityOptions.makeSceneTransitionAnimation(VegetableActivity.this).toBundle());
            }
        });

        edt_TextFilter.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) { }
            @Override
            public void afterTextChanged(Editable edit) {
                String filterText = edit.toString();
                ((ListViewAdapter)listView.getAdapter()).getFilter().filter(filterText);
            }
        });

        tv_TitleName.setText("채소");

        img_Revert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentMainActivty = new Intent(VegetableActivity.this,MainActivity.class);
                startActivity(intentMainActivty, ActivityOptions.makeSceneTransitionAnimation(VegetableActivity.this).toBundle());
            }
        });
    }
}