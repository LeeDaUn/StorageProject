package com.example.storageproject;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class IntnetMenu1 extends AppCompatActivity {
    TextView tv_NewData,tv_TitleName;
    ImageView img_Revert;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intnet_menu1);
        tv_NewData = findViewById(R.id.tv_newData);
        tv_TitleName =findViewById(R.id.tv_titleName);
        img_Revert = findViewById(R.id.iv_revert);

        tv_TitleName.setText("최근 찾아본 정보");
        img_Revert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentMainActivty = new Intent(IntnetMenu1.this,MainActivity.class);
                startActivity(intentMainActivty, ActivityOptions.makeSceneTransitionAnimation(IntnetMenu1.this).toBundle());
            }
        });
    }
}