package com.example.storageproject;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ActivityOptions;
import android.content.Intent;
import android.content.res.AssetManager;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;

public class VegetableSubActivity extends AppCompatActivity{

    TextView tv_Name,tv_Content,tv_TitleName;
    ImageView img_Revert;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_vegetable_sub);

        img_Revert = findViewById(R.id.iv_revert);
        tv_TitleName = findViewById(R.id.tv_titleName);
        tv_Name = findViewById(R.id.tv_testName);
        tv_Content = findViewById(R.id.tv_testContent);

        Intent MyIntent = getIntent();
        String sName = MyIntent.getStringExtra("Name");
        tv_Name.setText(sName);
        tv_TitleName.setText(sName);
        AssetManager assetManager = getAssets();
        try {
            InputStream obj = assetManager.open("vegetable.json");
            InputStreamReader jObject = new InputStreamReader(obj);
            BufferedReader reader = new BufferedReader(jObject);

            StringBuffer buffer = new StringBuffer();
            String line1 = reader.readLine();
            while (line1 != null) {
                buffer.append(line1 + "\n");
                line1 = reader.readLine();
            }
            String jsonData = buffer.toString();
            JSONObject jsonObject = new JSONObject(jsonData);
            String value = jsonObject.getString(sName);
            tv_Content.setText(value);
        } catch (JSONException | IOException e) {
        }
        img_Revert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentMainActivty = new Intent(VegetableSubActivity.this,VegetableActivity.class);
                startActivity(intentMainActivty, ActivityOptions.makeSceneTransitionAnimation(VegetableSubActivity.this).toBundle());
            }
        });
    };
}